class AppFont {
  static String get interBlack => 'Inter-Black';
  static String get interBlackItalic => 'Inter-BlackItalic';
  static String get interBold => 'Inter-Bold';
  static String get interBoldItalic => 'Inter-BoldItalic';
  static String get interExtraBold => 'Inter-ExtraBold';
  static String get interExtraBoldItalic => 'Inter-ExtraBoldItalic';
  static String get interExtraLightBETA =>'Inter-ExtraLight-BETA';
  static String get interItalic => 'Inter-Italic';
  static String get interLightBETA => 'Inter-Light-BETA';
  static String get interLightItalicBETA => 'Inter-LightItalic-BETA';
  static String get interMedium => 'Inter-Medium';

  static String get interMediumItalic => "Inter-MediumItalic";
  static String get interRegular => "Inter-Regular";
  static String get interSemiBold => "Inter-SemiBold";
  static String get interSemiBoldItalic => "Inter-SemiBoldItalic";
  static String get interThinBETA => "Inter-Thin-BETA";
  static String get interThinItalicBETA => "Inter-ThinItalic-BETA";

}